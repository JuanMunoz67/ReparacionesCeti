package com.example.reparacionesceti

import com.example.reparacionesceti.model.entities.Notification
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import coil3.load
import coil3.request.crossfade
import coil3.request.placeholder
import com.example.reparacionesceti.model.AppDatabase
import com.example.reparacionesceti.model.entities.Reporte
import com.example.reparacionesceti.preferences.Preferences
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CrearReporteActivity : AppCompatActivity() {
    private lateinit var imgView: ImageView
    private lateinit var etTitulo: EditText
    private lateinit var etUbicacion: EditText
    private lateinit var etDescripcion: EditText
    private lateinit var etNotas: EditText
    private lateinit var btnGuardar: Button
    private lateinit var chipGroupEstado: ChipGroup
    private lateinit var btnBorrar: Button

    private var currentPhotoUri: Uri? = null

    private lateinit var requestCameraPermissionLauncher: ActivityResultLauncher<String>
    private lateinit var requestGalleryPermissionLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var takePictureLauncher: ActivityResultLauncher<Uri>
    private lateinit var pickImageLauncher: ActivityResultLauncher<String>

    private lateinit var db: AppDatabase
    private var editMode = false
    private lateinit var userRole: String

    companion object {
        private const val EXTRA_REPORTE_ID = "reporteId"
    }

    private var reporte: Reporte? = null

    private fun init() {
        imgView = findViewById(R.id.imageViewUpload)
        etTitulo = findViewById(R.id.etReporteTitulo)
        etUbicacion = findViewById(R.id.etReporteUbicacion)
        etDescripcion = findViewById(R.id.etReporteDescripcion)
        etNotas = findViewById(R.id.etReporteNotas)
        btnGuardar = findViewById(R.id.btnDoRegister)
        chipGroupEstado = findViewById(R.id.chipGroupReporteEstado)
        btnBorrar = findViewById(R.id.btDeleteReport)

        imgView.setOnClickListener {
            showImageSourceDialog()
        }

        btnGuardar.setOnClickListener {
            saveReport()
            finish()
        }

        btnBorrar.setOnClickListener {
            deleteReport()
            finish()
        }

        btnBorrar.visibility = View.GONE
        btnBorrar.isEnabled = false

        db = AppDatabase.getDatabase(this)
        userRole = Preferences.currentUser!!.role
    }

    private fun setValuesIfAny() {
        val reportedId = intent.getLongExtra(EXTRA_REPORTE_ID, -1L)

        if (reportedId != -1L) {
            editMode = true
            lifecycleScope.launch {
                reporte = db.reporteDao().obtenerPorId(reportedId)

                reporte?.let {
                    etTitulo.setText(it.titulo)
                    etUbicacion.setText(it.ubicacion)
                    etDescripcion.setText(it.descripcion)
                    etNotas.setText(it.notas)
                    chipGroupEstado.check(
                        when (it.estado) {
                            "Pendiente" -> R.id.chipPendiente
                            "En proceso" -> R.id.chipEnProceso
                            "resuelto" -> R.id.chipResuelto
                            else -> -1
                        }
                    )
                    imgView.load(it.imagenUri) {
                        crossfade(true)
                        placeholder(R.drawable.baseline_add_a_photo_24)
                    }
                }
            }
            btnGuardar.text = "Actualizar"

            if (userRole == "estudiante") {
                imgView.isEnabled = false
                etTitulo.isEnabled = false
                etUbicacion.isEnabled = false
                etDescripcion.isEnabled = false
                etNotas.isEnabled = false
                chipGroupEstado.isEnabled = false
                btnGuardar.isEnabled = false
                btnBorrar.isEnabled = false
            }

            if (userRole == "tecnico") {
                etTitulo.isEnabled = false
                etUbicacion.isEnabled = false
                etDescripcion.isEnabled = false
                etNotas.isEnabled = true
                chipGroupEstado.isEnabled = true
                btnGuardar.isEnabled = true
                btnBorrar.isEnabled = false
            }

            if (userRole == "admin") {
                etTitulo.isEnabled = true
                etUbicacion.isEnabled = true
                etDescripcion.isEnabled = true
                etNotas.isEnabled = true
                chipGroupEstado.isEnabled = true
                btnBorrar.visibility = View.VISIBLE
                btnBorrar.isEnabled = true
            }
        }
    }

    private fun saveReport() {
        val titulo = etTitulo.text.toString().trim()
        val ubicacion = etUbicacion.text.toString().trim()
        val descripcion = etDescripcion.text.toString()
        val notas = etNotas.text.toString()
        val imagenUri = currentPhotoUri.toString()
        val estadoId = chipGroupEstado.checkedChipId
        val estadoReporte = findViewById<Chip>(estadoId)?.text.toString().lowercase()

        if (titulo.isNotEmpty() && ubicacion.isNotEmpty() && descripcion.isNotEmpty() && estadoReporte.isNotEmpty()) {
            val timeStamp: String = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

            lifecycleScope.launch {
                if (!editMode) {
                    // Create new report object (without ID)
                    val newReport = Reporte(
                        titulo = titulo,
                        ubicacion = ubicacion,
                        descripcion = descripcion,
                        notas = notas,
                        estado = estadoReporte,
                        imagenUri = imagenUri,
                        fecha = timeStamp
                    )

                    // Insert and get the generated ID
                    val reportId = db.reporteDao().insertar(newReport)

                    // Create notification with the correct ID
                    val notification = Notification(
                        reportId = reportId,  // Use the returned ID
                        title = "Nuevo reporte creado",
                        message = "Se ha creado el reporte: $titulo",
                        actionType = "create"
                    )
                    db.notificationDao().insert(notification)
                    sendNotification(notification)
                } else {
                    // For existing reports, use the existing ID
                    val oldEstado = reporte?.estado
                    val currentReportId = reporte?.id ?: return@launch

                    reporte?.apply {
                        this.titulo = titulo
                        this.ubicacion = ubicacion
                        this.descripcion = descripcion
                        this.notas = notas
                        this.estado = estadoReporte
                        this.imagenUri = imagenUri
                    }

                    reporte?.let { db.reporteDao().actualizar(it) }

                    if (oldEstado != estadoReporte) {
                        val notification = Notification(
                            reportId = currentReportId,  // Use the existing report ID
                            title = "Estado actualizado",
                            message = "El reporte '$titulo' cambió de estado a $estadoReporte",
                            actionType = "update",
                            technicianName = Preferences.currentUser?.name
                        )
                        db.notificationDao().insert(notification)
                        sendNotification(notification)
                    }
                }
            }
        } else {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendNotification(notification: Notification) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "report_updates",
                "Actualizaciones de Reportes",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notificaciones sobre cambios en reportes"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("notification_id", notification.id)
            putExtra("fragment_to_open", "notifications")
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            notification.id.hashCode(), // Using hashCode() to safely convert Long to Int
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val (title, message) = notification.getNotificationContent()
        val builder = NotificationCompat.Builder(this, "report_updates")
            .setSmallIcon(R.drawable.ic_notifications_black_24dp)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setWhen(notification.timestamp)

        notificationManager.notify(notification.id.hashCode(), builder.build())
    }

    private fun deleteReport() {
        if (reporte == null || userRole != "admin") return
        lifecycleScope.launch {
            val currentReportId = reporte?.id ?: return@launch
            val notification = Notification(
                reportId = currentReportId,
                title = "Reporte eliminado",
                message = "El reporte '${reporte!!.titulo}' ha sido eliminado",
                actionType = "delete",
                technicianName = Preferences.currentUser?.name
            )
            db.notificationDao().insert(notification)
            sendNotification(notification)
        }
        Toast.makeText(this, "Reporte eliminado", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_crear_reporte)

        init()
        setupLaunchers()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setValuesIfAny()
    }

    private fun setupLaunchers() {
        requestCameraPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
                if (isGranted) {
                    openCamera()
                } else {
                    Toast.makeText(this, "Permiso de cámara denegado", Toast.LENGTH_SHORT).show()
                }
            }

        requestGalleryPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
                val readMediaImagesGranted = permissions[Manifest.permission.READ_MEDIA_IMAGES] ?: false
                val readExternalStorageGranted = permissions[Manifest.permission.READ_EXTERNAL_STORAGE] ?: false

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (readMediaImagesGranted) {
                        openGallery()
                    } else {
                        Toast.makeText(this, "Permiso de galería denegado", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (readExternalStorageGranted) {
                        openGallery()
                    } else {
                        Toast.makeText(this, "Permiso de galería denegado", Toast.LENGTH_SHORT).show()
                    }
                }
            }

        takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                currentPhotoUri?.let { uri ->
                    imgView.load(uri) {
                        crossfade(true)
                        placeholder(R.drawable.baseline_add_a_photo_24)
                    }
                }
            } else {
                Toast.makeText(this, "Error al tomar la foto.", Toast.LENGTH_SHORT).show()
                currentPhotoUri = null
            }
        }

        pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                currentPhotoUri = it
                imgView.load(it) {
                    crossfade(true)
                    placeholder(R.drawable.baseline_add_a_photo_24)
                }
            }
        }
    }

    private fun showImageSourceDialog() {
        val options = arrayOf("Tomar foto", "Elegir de la galería")
        AlertDialog.Builder(this)
            .setTitle("Seleccionar Imagen")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> checkCameraPermissionAndOpenCamera()
                    1 -> checkGalleryPermissionAndOpenGallery()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        } else {
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun checkGalleryPermissionAndOpenGallery() {
        val permissionsToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        var allPermissionsGranted = true
        for (permission in permissionsToRequest) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false
                break
            }
        }

        if (allPermissionsGranted) {
            openGallery()
        } else {
            requestGalleryPermissionLauncher.launch(permissionsToRequest)
        }
    }

    private fun openCamera() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: Exception) {
            Toast.makeText(this, "Error al crear archivo de imagen", Toast.LENGTH_SHORT).show()
            null
        }
        photoFile?.also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                it
            )
            currentPhotoUri = photoURI
            takePictureLauncher.launch(photoURI)
        }
    }

    private fun openGallery() {
        pickImageLauncher.launch("image/*")
    }

    @Throws(Exception::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = getExternalFilesDir("Pictures")
        if (storageDir != null && !storageDir.exists()) {
            storageDir.mkdirs()
        }

        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        )
    }
}