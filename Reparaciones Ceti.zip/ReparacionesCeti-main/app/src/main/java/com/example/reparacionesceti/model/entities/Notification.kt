package com.example.reparacionesceti.model.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,  // Changed from Int to Long
    val reportId: Long,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val technicianName: String? = null,
    val actionType: String // "create", "update", "delete"
) {
    fun getNotificationContent(): Pair<String, String> {
        return title to message
    }
}