// NotificationsFragment.kt
package com.example.reparacionesceti

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.reparacionesceti.databinding.FragmentNotificationsBinding
import com.example.reparacionesceti.model.AppDatabase
import com.example.reparacionesceti.model.NotificationAdapter
import kotlinx.coroutines.launch

class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!
    private lateinit var db: AppDatabase
    private lateinit var adapter: NotificationAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        adapter = NotificationAdapter { notification ->
            // Marcar como leída al hacer clic
            if (!notification.isRead) {
                lifecycleScope.launch {
                    db.notificationDao().markAsRead(notification.id)
                }
            }

            // Opcional: navegar al reporte si no fue eliminado
            if (notification.actionType != "delete") {
                // Implementa navegación al reporte si lo deseas
            }
        }

        binding.recyclerNotifications.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerNotifications.adapter = adapter

        // Observar cambios en las notificaciones
        db.notificationDao().getAllNotifications().observe(viewLifecycleOwner) { notifications ->
            adapter.updateList(notifications)

            if (notifications.isEmpty()) {
                binding.textEmpty.visibility = View.VISIBLE
                binding.recyclerNotifications.visibility = View.GONE
            } else {
                binding.textEmpty.visibility = View.GONE
                binding.recyclerNotifications.visibility = View.VISIBLE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}