package com.example.reparacionesceti.model

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.reparacionesceti.R

class TechnicianStatsAdapter : ListAdapter<TechnicianStats, TechnicianStatsAdapter.TechnicianStatsViewHolder>(TechnicianStatsDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TechnicianStatsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_technician_stats, parent, false)
        return TechnicianStatsViewHolder(view)
    }

    override fun onBindViewHolder(holder: TechnicianStatsViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, position + 1) // position + 1 for ranking number
    }

    class TechnicianStatsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val rankText: TextView = view.findViewById(R.id.tvRank)
        private val nameText: TextView = view.findViewById(R.id.tvTechnicianName)
        private val completedText: TextView = view.findViewById(R.id.tvCompletedCases)
        private val pendingText: TextView = view.findViewById(R.id.tvPendingCases)

        fun bind(stats: TechnicianStats, rank: Int) {
            rankText.text = "#$rank"
            nameText.text = stats.technicianName
            completedText.text = stats.completedCases.toString()
            pendingText.text = stats.pendingCases.toString()
        }
    }
}

class TechnicianStatsDiffCallback : DiffUtil.ItemCallback<TechnicianStats>() {
    override fun areItemsTheSame(oldItem: TechnicianStats, newItem: TechnicianStats): Boolean {
        return oldItem.technicianId == newItem.technicianId
    }

    override fun areContentsTheSame(oldItem: TechnicianStats, newItem: TechnicianStats): Boolean {
        return oldItem == newItem
    }
}