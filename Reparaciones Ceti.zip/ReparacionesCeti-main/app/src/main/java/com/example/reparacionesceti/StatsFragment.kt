package com.example.reparacionesceti

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.reparacionesceti.databinding.FragmentStatsBinding
import com.example.reparacionesceti.model.AppDatabase
import com.example.reparacionesceti.model.TechnicianStatsAdapter
import kotlinx.coroutines.launch

class StatsFragment : Fragment() {
    private var _binding: FragmentStatsBinding? = null
    private val binding get() = _binding!!
    private lateinit var db: AppDatabase
    private lateinit var adapter: TechnicianStatsAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStatsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())
        adapter = TechnicianStatsAdapter()

        binding.recyclerStats.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@StatsFragment.adapter
            setHasFixedSize(true)
        }

        loadTechnicianStats()
    }

    private fun loadTechnicianStats() {
        lifecycleScope.launch {
            try {
                db.reporteDao().getTechnicianStatsFlow().collect { stats ->
                    Log.d("StatsDebug", "Datos recibidos: ${stats.size} técnicos")
                    stats.forEach { stat ->
                        Log.d("StatsDebug",
                            "Técnico: ${stat.technicianName}, " +
                                    "resueltos: ${stat.completedCases}, " +
                                    "pendientes: ${stat.pendingCases}")
                    }

                    adapter.submitList(stats)
                    updateEmptyState(stats.isEmpty())
                }
            } catch (e: Exception) {
                Log.e("StatsError", "Error al cargar estadísticas", e)
                binding.textEmpty.text = "Error al cargar datos"
                updateEmptyState(true)
            }
        }
    }

    private fun updateEmptyState(isEmpty: Boolean) {
        binding.textEmpty.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.recyclerStats.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}