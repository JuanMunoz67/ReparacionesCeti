// NotificationAdapter.kt
package com.example.reparacionesceti.model

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.reparacionesceti.R
import com.example.reparacionesceti.model.entities.Notification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationAdapter(
    private var notifications: List<Notification> = emptyList(),
    private val onItemClick: (Notification) -> Unit
) : RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder>() {

    inner class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        private val tvMessage: TextView = itemView.findViewById(R.id.tvMessage)
        private val tvTechnician: TextView = itemView.findViewById(R.id.tvTechnician)
        private val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        private val unreadIndicator: View = itemView.findViewById(R.id.viewUnreadIndicator)

        fun bind(notification: Notification) {
            tvTitle.text = notification.title
            tvMessage.text = notification.message

            if (notification.technicianName != null) {
                tvTechnician.text = "Por: ${notification.technicianName}"
                tvTechnician.visibility = View.VISIBLE
            } else {
                tvTechnician.visibility = View.GONE
            }

            val date = Date(notification.timestamp)
            val format = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            tvTime.text = format.format(date)

            unreadIndicator.visibility = if (notification.isRead) View.GONE else View.VISIBLE

            itemView.setOnClickListener {
                onItemClick(notification)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_notification, parent, false)
        return NotificationViewHolder(view)
    }

    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
        holder.bind(notifications[position])
    }

    override fun getItemCount(): Int = notifications.size

    fun updateList(newList: List<Notification>) {
        notifications = newList
        notifyDataSetChanged()
    }
}