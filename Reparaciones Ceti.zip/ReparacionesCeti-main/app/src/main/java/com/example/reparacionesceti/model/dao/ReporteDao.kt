package com.example.reparacionesceti.model.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.reparacionesceti.model.TechnicianStats
import com.example.reparacionesceti.model.entities.Reporte
import kotlinx.coroutines.flow.Flow

@Dao
interface ReporteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(reporte: Reporte): Long

    @Query("SELECT * FROM reportes ORDER BY fecha DESC")
    fun observarTodos(): LiveData<List<Reporte>>

    @Query("SELECT * FROM reportes ORDER BY fecha DESC")
    suspend fun obtenerTodos(): List<Reporte>

    @Update
    suspend fun actualizar(reporte: Reporte)

    @Query("DELETE FROM reportes WHERE id = :reporteId")
    suspend fun eliminarPorId(reporteId: Long)

    @Query("SELECT * FROM reportes WHERE id = :reporteId")
    suspend fun obtenerPorId(reporteId: Long): Reporte?

    @Query("""
    SELECT 
        u.id as technicianId,
        u.name as technicianName,
        SUM(CASE WHEN r.estado = 'resuelto' THEN 1 ELSE 0 END) as completedCases,
        SUM(CASE WHEN r.estado != 'resuelto' THEN 1 ELSE 0 END) as pendingCases
    FROM reportes r
    JOIN users u ON r.technician_id = u.id
    WHERE u.role = 'tecnico' || u.role = 'Técnico'
    GROUP BY u.id, u.name
    ORDER BY completedCases DESC
""")
    fun getTechnicianStatsFlow(): Flow<List<TechnicianStats>>
}