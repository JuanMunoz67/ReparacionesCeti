package com.example.reparacionesceti.model

data class TechnicianStats(
    val technicianId: Long,
    val technicianName: String,
    val completedCases: Int,
    val pendingCases: Int
)