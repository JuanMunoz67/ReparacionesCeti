# ReparacionesCeti
## Proyecto moviles

### 13 jun
Hubo cambio en la BD, hay que desinstalar la app para volver a ejecutar
